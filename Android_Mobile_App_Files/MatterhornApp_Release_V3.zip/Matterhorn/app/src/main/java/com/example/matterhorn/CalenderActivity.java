package com.example.matterhorn;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import org.bson.BsonArray;
import org.bson.BsonValue;
import org.bson.Document;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;


public class CalenderActivity extends HomePage {


    Button ChangeDate;
    TextView CurrentDate;
    CalendarView mCalendarView;
    private String tempDate = "BLANK_DATE";

    ListView ListSlots;
    EditText SearchReservations;
    ArrayList<String> TimeSlots = new ArrayList<>();

    public static String mDATE;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calender);
        //getSupportActionBar().set
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar23);


        setSupportActionBar(toolbar);

        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN); //KEEPS KEYBOARD FROM POPPING UP RANDOMLY

        Window window = this.getWindow();
        window.setStatusBarColor(this.getResources().getColor(R.color.design_default_color_primary_dark));

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);



        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(getApplicationContext(),ViewSchedulers.class));
                finish();
                ReturnToSchedulers();
            }
        });

        ChangeDate = (Button)findViewById(R.id.ChangeDate);
        CurrentDate = (TextView)findViewById(R.id.CurrentDateText);

        ChangeDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ChangeTheDate();
            }
        });
        //String day = dayofweek(, 4, 2019);
        Calendar cal = Calendar.getInstance();
        DateFormat df = new SimpleDateFormat("M-dd-yyyy");
        String date_str = df.format(cal.getTime());
        String day_str = "Today";
        int day = cal.get(cal.DAY_OF_WEEK);
        switch(day){
            case Calendar.SUNDAY:
                day_str = "Sunday";
                break;
            case Calendar.MONDAY:
                day_str = "Monday";
                break;
            case Calendar.TUESDAY:
                day_str = "Tuesday";
                break;
            case Calendar.WEDNESDAY:
                day_str = "Wednesday";
                break;
            case Calendar.THURSDAY:
                day_str = "Thursday";
                break;
            case Calendar.FRIDAY:
                day_str = "Friday";
                break;
            case Calendar.SATURDAY:
                day_str = "Saturday";
                break;
        }
        SessionData.CurrRes.ResDay = day_str;
        SessionData.CurrRes.ResDate = date_str;

        CurrentDate.setText("Times Available Today  - "+date_str);

        /////////////////////////////////////////////////////////////////

        ListSlots = (ListView) findViewById(R.id.TimeSlots);

        ListSlots.setEmptyView(findViewById(R.id.emptyElement2)); ///////////////

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, TimeSlots);
        ListSlots.setAdapter(adapter);

        GetTimes(date_str);


        //adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, TimeSlots);
        //ListSlots.setAdapter(adapter);

        ListSlots.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String text = ListSlots.getItemAtPosition(position).toString();
                Toast.makeText(CalenderActivity.this, "" + text, Toast.LENGTH_SHORT).show();
                SessionData.CurrRes.ResTime = text.toUpperCase();

                ReservationDialog();
            }
        });

    }

    private void ReservationDialog(){

        AlertDialog.Builder mBuilder = new AlertDialog.Builder(CalenderActivity.this,AlertDialog.THEME_HOLO_LIGHT);
        View mView = getLayoutInflater().inflate(R.layout.reservation_form,null);
        final EditText CommentsForm = (EditText) mView.findViewById(R.id.CommentsForm);
        final TextView DateForm = (TextView) mView.findViewById(R.id.Res_Date);
        final TextView DayTimeForm = (TextView) mView.findViewById(R.id.Res_Day_Time);

        DateForm.setText("Date: "+SessionData.CurrRes.ResDate);
        DayTimeForm.setText("Day/Time: "+SessionData.CurrRes.ResDay+" - "+SessionData.CurrRes.ResTime);


        mBuilder.setTitle("Reservation Info")
                // Add action buttons
                .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        Toast.makeText(CalenderActivity.this,"Reservation Successfully Made", Toast.LENGTH_SHORT).show();
                        //Reservation_dialog.dismiss();
                        InsertIntoDB(SessionData.CurrSchedule.ScheduleID,SessionData.CurrUser.UserID,SessionData.CurrScheduler.SchedulerName,SessionData.CurrSchedule.ScheduleName, SessionData.CurrRes.ResTime,SessionData.CurrRes.ResDate,CommentsForm.getText().toString());





                        //MyReservations.add(" "+SessionData.CurrScheduler.SchedulerName+" - "+SessionData.CurrSchedule.ScheduleName+"\n Day: "+SessionData.CurrRes.ResDay+"\n Time: "+SessionData.CurrRes.ResTime+"\n Date: "+SessionData.CurrRes.ResDate);

                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                });
        mBuilder.setView(mView);
        final AlertDialog Reservation_dialog = mBuilder.create();
        Reservation_dialog.show();

    }

    static String dayofweek(int d, int m, int y)
    {
        int t[] = { 0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4 };
        y -= (m < 3) ? 1 : 0;
        int temp =  ( y + y/4 - y/100 + y/400 + t[m-1] + d) % 7;
        if(temp==1)
            return "Monday";
        if(temp==2)
            return "Tuesday";
        if(temp==3)
            return "Wednesday";
        if(temp==4)
            return "Thursday";
        if(temp==5)
            return "Friday";
        if(temp==6)
            return "Saturday";
        if(temp==0)
            return "Sunday";
        return "Unknown Day";
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        return false;
    }

    public void InsertIntoDB(String S_id,String U_id,String sr, String s, String t, String d,String comments){
        Document document = new Document("ScheduleID", S_id)
                .append("UserID", U_id)
                .append("SchedulerName", sr)
                .append("ScheduleName", s)
                .append("Time", t)
                .append("Date", d)
                .append("Comments", comments);
        client.callFunction("AddReservation", Arrays.asList(document),BsonValue.class)
                .addOnCompleteListener(new OnCompleteListener<BsonValue>() {
                    @Override
                    public void onComplete(@NonNull final Task<BsonValue> task) {
                        if (task.isSuccessful()) {
                            //ShowReservations();
                            ReturnHome();
                        }
                        else {
                            Log.e("stitch", "Error calling function:", task.getException());
                        }
                    }
                });



    }

    public String getStartTime(int temp){
        if(temp==2)
            return SessionData.CurrSchedule.ScheduleObj.getString("M_START").getValue().toString();
        if(temp==3)
            return SessionData.CurrSchedule.ScheduleObj.getString("T_START").getValue().toString();
        if(temp==4)
            return SessionData.CurrSchedule.ScheduleObj.getString("W_START").getValue().toString();
        if(temp==5)
            return SessionData.CurrSchedule.ScheduleObj.getString("Th_START").getValue().toString();
        if(temp==6)
            return SessionData.CurrSchedule.ScheduleObj.getString("F_START").getValue().toString();
        if(temp==7)
            return SessionData.CurrSchedule.ScheduleObj.getString("S_START").getValue().toString();
        if(temp==1)
            return SessionData.CurrSchedule.ScheduleObj.getString("Su_START").getValue().toString();
        return "Unknown Day";
    }

    public String getEndTime(int temp){
        if(temp==2)
            return SessionData.CurrSchedule.ScheduleObj.getString("M_END").getValue().toString();
        if(temp==3)
            return SessionData.CurrSchedule.ScheduleObj.getString("T_END").getValue().toString();
        if(temp==4)
            return SessionData.CurrSchedule.ScheduleObj.getString("W_END").getValue().toString();
        if(temp==5)
            return SessionData.CurrSchedule.ScheduleObj.getString("Th_END").getValue().toString();
        if(temp==6)
            return SessionData.CurrSchedule.ScheduleObj.getString("F_END").getValue().toString();
        if(temp==7)
            return SessionData.CurrSchedule.ScheduleObj.getString("S_END").getValue().toString();
        if(temp==1)
            return SessionData.CurrSchedule.ScheduleObj.getString("Su_END").getValue().toString();
        return "Unknown Day";
    }

    public void GetTimes(String date){

        TimeSlots.clear();

        SimpleDateFormat format = new SimpleDateFormat("M-dd-yyyy");

        int day = -1;
        try {
            Date date2 = format.parse(date);
            Calendar cal = Calendar.getInstance();
            cal.setTime(date2);
            day = cal.get(cal.DAY_OF_WEEK);

        } catch (ParseException e) {
            e.printStackTrace();
        }



        //String DAY = dayofweek(day);

        String start_time = getStartTime(day);
        System.out.println("                         START    TIME    "+start_time);
        String end_time = getEndTime(day);
        System.out.println("                         END    TIME    "+end_time);
        String res_length = SessionData.CurrSchedule.ScheduleObj.getString("average_appointment_length").getValue().toString();

        //String start_time = "09:00 AM";
        //String end_time = "05:00 PM";
        //String res_length = "30";

        String start_hour = new StringBuilder().append(start_time.charAt(0)).append(start_time.charAt(1)).toString();
        int start_H = Integer.parseInt(start_hour);
        String start_min = new StringBuilder().append(start_time.charAt(3)).append(start_time.charAt(4)).toString(); //either 00 mins or 30 mins
        int start_M = Integer.parseInt(start_min);

        String end_hour = new StringBuilder().append(end_time.charAt(0)).append(end_time.charAt(1)).toString();
        int end_H = Integer.parseInt(end_hour);
        String end_min = new StringBuilder().append(end_time.charAt(3)).append(end_time.charAt(4)).toString(); //either 00 mins or 30 mins
        int end_M = Integer.parseInt(end_min);


        if(start_time.charAt(6)== 'P' && start_H < 12 && start_H > 0){
            start_H += 12;
        }
        if(end_time.charAt(6)== 'P' && end_H < 12 && end_H > 0){
            end_H += 12;
        }

        int hours = end_H - start_H;

        if(res_length.equals("30"))
            hours = hours*2;

        ArrayList<String> x_times = new ArrayList();
        //System.out.println(hours);

        int starting = start_H;

        for(int i = 0;i < hours;i++)
        {
            if(res_length.equals("30"))
            {
                if(i % 2 == 0)
                {
                    int temp = starting;
                    String A_OR_P = "AM";
                    if(temp >= 12)
                    {
                        if(temp > 12)
                            temp -= 12;
                        A_OR_P = "PM";
                    }
                    x_times.add(temp+":"+"00"+" "+A_OR_P);
                    //starting++;
                }
                else
                {
                    int temp = starting;
                    String A_OR_P = "AM";
                    if(temp >= 12)
                    {
                        if(temp > 12)
                            temp -= 12;
                        A_OR_P = "PM";
                    }
                    x_times.add(temp+":"+"30"+" "+A_OR_P);
                    starting++;
                }
            }
            else
            {
                int temp = starting;
                String A_OR_P = "AM";
                if(temp >= 12)
                {
                    if(temp > 12)
                        temp -= 12;
                    A_OR_P = "PM";
                }
                x_times.add(temp+":"+"00"+" "+A_OR_P);
                starting++;
            }


        }

        Document document = new Document("SchedulerName", SessionData.CurrScheduler.SchedulerName)
                .append("ScheduleName", SessionData.CurrSchedule.ScheduleName)
                .append("Date", date);

        ArrayList<String> taken_times = new ArrayList();

        client.callFunction("ListMyAppointments", Arrays.asList(document), BsonArray.class)
                .addOnCompleteListener(new OnCompleteListener<BsonArray>() {
                    @Override
                    public void onComplete(@NonNull final Task<BsonArray> task) {
                        if (task.isSuccessful()) {
                            Log.d("stitch", task.getResult().toString());
                            for (BsonValue doc: task.getResult()) {
                                taken_times.add(doc.asDocument().getString("Time").getValue());
                            }

                            for(String h : taken_times)
                            {
                                x_times.remove(h);
                            }

                            for(String t : x_times)
                            {
                                TimeSlots.add(t);
                            }
                            adapter.notifyDataSetChanged();
                        }
                        else {
                            Log.e("stitch", "Error calling function:", task.getException());
                        }
                    }
                });
    }

    public void ReturnHome() {
        finish();
        Intent intent = new Intent(this, HomePage.class);
        startActivity(intent);
    }

    public void ReturnToSchedulers(){
        finish();
        Intent intent = new Intent(this, ViewSchedulers.class);
        startActivity(intent);
    }

    private void ChangeTheDate(){



        AlertDialog.Builder mBuilder = new AlertDialog.Builder(CalenderActivity.this,AlertDialog.THEME_HOLO_LIGHT);
        View mView = getLayoutInflater().inflate(R.layout.activity_calender_date,null);

        mCalendarView = (CalendarView) mView.findViewById(R.id.calendarView);
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                String date = (month+1) + "-" + dayOfMonth + "-"+ year ;
                mDATE = date;
                String day = dayofweek(dayOfMonth, month+1, year);
                tempDate = "Times Available On "+day+" - "+date;

                SessionData.CurrRes.ResDay = day;
                SessionData.CurrRes.ResDate = date;
            }
        });

        mBuilder.setTitle("Select Date")
                .setPositiveButton("Set", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        CurrentDate.setText(tempDate);
                        GetTimes(mDATE);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                });
        mBuilder.setView(mView);
        final AlertDialog calendar_dialog = mBuilder.create();
        calendar_dialog.show();



    }

}
