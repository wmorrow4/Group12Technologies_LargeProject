package com.example.matterhorn;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.support.v7.widget.Toolbar;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import org.bson.BsonArray;
import org.bson.BsonDocument;
import org.bson.BsonValue;
import org.bson.Document;

import java.util.ArrayList;
import java.util.Arrays;

public class ViewSchedulers extends LoginActivity {

    ListView mSchedulers;
    EditText SearchSchedulers;
    ArrayList<String> TheSchedulers = new ArrayList<>();
    ArrayList<BsonDocument> SchedulerDocs = new ArrayList<>();
    ArrayList<String> TheirSchedules = new ArrayList<>();
    ArrayList<BsonDocument> ScheduleDocs = new ArrayList<>();
    public static ArrayAdapter<String> adapter;
    public static ArrayAdapter<String> adapter2;

    public static int cur_position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_schedulers);
        // Find the toolbar view inside the activity layout

        //getSupportActionBar().setDisplayShowHomeEnabled(true);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar22);
        setSupportActionBar(toolbar);


        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN); //KEEPS KEYBOARD FROM POPPING UP RANDOMLY

        Window window = this.getWindow();
        window.setStatusBarColor(this.getResources().getColor(R.color.design_default_color_primary_dark));
        // Sets the Toolbar to act as the ActionBar for this Activity window.
        // Make sure the toolbar exists in the activity and is not null
        //setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(getApplicationContext(),ViewSchedulers.class));
                finish();
                ReturnToHomePage();
            }
        });

        mSchedulers = (ListView) findViewById(R.id.SchedulersList);
        ListSchedulers();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, TheSchedulers);
        mSchedulers.setAdapter(adapter);

        mSchedulers.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                adapter.notifyDataSetChanged();
                String text = mSchedulers.getItemAtPosition(position).toString();
                Toast.makeText(ViewSchedulers.this, "" + text, Toast.LENGTH_SHORT).show();
                SessionData.CurrScheduler.SchedulerName = text;
                String S_ID = SchedulerDocs.get(position).getObjectId("_id").getValue().toString();
                ViewTheirSchedules(S_ID,position);
            }
        });

        SearchSchedulers = (EditText) findViewById(R.id.SearchScheduelers);

        SearchSchedulers.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ArrayList<String> tempList = new ArrayList<>();

                for (String temp : TheSchedulers) {
                    if (temp.toLowerCase().contains(s.toString().toLowerCase())) {
                        tempList.add(temp);
                    }
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<>(ViewSchedulers.this, android.R.layout.simple_list_item_1, tempList);
                mSchedulers.setAdapter(adapter);
                //return true;
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


    }

    public void ListSchedulers() {
        client.callFunction("ListSchedulers", null, BsonArray.class)
        .addOnCompleteListener(new OnCompleteListener<BsonArray>() {
            @Override
            public void onComplete(@NonNull final Task<BsonArray> task) {
                if (task.isSuccessful()) {
                    Log.d("stitch", task.getResult().toString());

                    for (BsonValue doc: task.getResult()) {
                        TheSchedulers.add(doc.asDocument().getString("group").getValue());
                        SchedulerDocs.add(doc.asDocument());
                    }

                    adapter.notifyDataSetChanged();
                }
                else {
                    Log.e("stitch", "Error calling function:", task.getException());
                }
            }
        });
    }




    public void ReturnToHomePage() {
        finish();
        //ShowReservations();
        Intent intent = new Intent(this, HomePage.class);
        startActivity(intent);
    }

    public void GoToTimeList() {
        //finish();
        Intent intent = new Intent(this, CalenderActivity.class);
        startActivity(intent);
    }

    private void ViewTheirSchedules(String S_ID, int position){

        AlertDialog.Builder mBuilder = new AlertDialog.Builder(ViewSchedulers.this,AlertDialog.THEME_HOLO_LIGHT);
        View mView = getLayoutInflater().inflate(R.layout.activity_view_schedules,null);

        final ListView mSchedules;
        TheirSchedules = new ArrayList<>();



        mSchedules = (ListView) mView.findViewById(R.id.SchedulesList);

        mSchedules.setEmptyView(mView.findViewById(R.id.emptyElement)); /////////////// here sets empty if scheduler has not schedules

        ListSchedules(S_ID,position);

        adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, TheirSchedules);
        mSchedules.setAdapter(adapter2);

        mSchedules.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String text = mSchedules.getItemAtPosition(position).toString();
                Toast.makeText(ViewSchedulers.this, "" + text, Toast.LENGTH_SHORT).show();
                SessionData.CurrSchedule.ScheduleName = text;
                SessionData.CurrSchedule.ScheduleObj = ScheduleDocs.get(position);
                SessionData.CurrSchedule.ScheduleID = SessionData.CurrSchedule.ScheduleObj.getObjectId("_id").getValue().toString();
                GoToTimeList();
            }
        });

        mBuilder.setTitle("Their Schedules")
                // Add action buttons

                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SessionData.CurrSchedule.ScheduleName = null;
                        SessionData.CurrScheduler.SchedulerName = null;
                    }
                });
        mBuilder.setView(mView);
        final AlertDialog Schedules_dialog = mBuilder.create();
        Schedules_dialog.show();

    }

    public void ListSchedules(String S_ID,int position) {
        Document temp_doc = new Document("schedulerID", S_ID);

        System.out.println("                                                             ----                         "+S_ID);



        client.callFunction("ListSchedulesV2", Arrays.asList(S_ID), BsonArray.class)
                .addOnCompleteListener(new OnCompleteListener<BsonArray>() {
                    @Override
                    public void onComplete(@NonNull final Task<BsonArray> task) {
                        if (task.isSuccessful()) {
                            Log.d("stitch", task.getResult().toString());

                            TheirSchedules.clear();
                            ScheduleDocs.clear();

                            for (BsonValue doc: task.getResult()) {
                                TheirSchedules.add(doc.asDocument().getString("schedule_name").getValue());
                                ScheduleDocs.add(doc.asDocument());
                            }

                            adapter2.notifyDataSetChanged();
                        }
                        else {
                            Log.e("stitch", "Error calling function:", task.getException());
                        }
                    }
                });
    }
}
