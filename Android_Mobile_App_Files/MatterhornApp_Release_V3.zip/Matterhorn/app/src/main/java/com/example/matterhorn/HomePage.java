package com.example.matterhorn;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import org.bson.BsonArray;
import org.bson.BsonValue;
import org.bson.Document;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

public class HomePage extends LoginActivity {

    ListView ListMyReservations;
    //listView_adapter listView_adapter2;
    EditText SearchMyReservations;
    Button MakeReservationB;

    public static ArrayAdapter<String> adapter;

    //public static ArrayList<String> MyReservations  = new ArrayList<>();;



    //ArrayAdapter listView_adapter2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //MyReservations = new ArrayList<>();

        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN); //KEEPS KEYBOARD FROM POPPING UP RANDOMLY


        MakeReservationB = (Button)findViewById(R.id.MakeReservationButton);

        MakeReservationB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ViewSchedulers();
            }
        });

        ListMyReservations = (ListView) findViewById(R.id.MyReservations);
        MyReservations.clear();
        ShowReservations();

        ListMyReservations.setEmptyView(findViewById(R.id.emptyElement3)); ///////////////


        adapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,MyReservations);
        ListMyReservations.setAdapter(adapter);

        ListMyReservations.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //String text = ListMyReservations.getItemAtPosition(position).toString();
                //Toast.makeText(HomePage.this,"" + text,Toast.LENGTH_SHORT).show();

                CancelRes(SessionData.CurrReservationsList.get(position),position);
                adapter.notifyDataSetChanged();
                //adapter.notifyDataSetChanged();

            }
        });

        SearchMyReservations = (EditText) findViewById(R.id.SearchMyReservationsFilter);

        SearchMyReservations.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ArrayList<String> tempList = new ArrayList<>();

                for(String temp: MyReservations){
                        if(temp.toLowerCase().contains(s.toString().toLowerCase())){
                        tempList.add(temp);
                    }
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<>(HomePage.this,android.R.layout.simple_list_item_1,tempList);
                ListMyReservations.setAdapter(adapter);
                //return true;
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        //ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
         //       this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        //drawer.addDrawerListener(toggle);
        //toggle.syncState();

        drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);

        //NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        //navigationView.setNavigationItemSelectedListener(this);
    }

    public void ShowReservations(){
        Document document = new Document("UserID", SessionData.CurrUser.UserID);

        SessionData.CurrReservationsList.clear();
        MyReservations.clear();

        client.callFunction("ListMyAppointments", Arrays.asList(document), BsonArray.class)
                .addOnCompleteListener(new OnCompleteListener<BsonArray>() {
                    @Override
                    public void onComplete(@NonNull final Task<BsonArray> task) {
                        if (task.isSuccessful()) {
                            Log.d("stitch", task.getResult().toString());

                            for (BsonValue doc: task.getResult()) {

                                SimpleDateFormat format = new SimpleDateFormat("M-dd-yyyy");
                                try {
                                    Date date = format.parse(doc.asDocument().getString("Date").getValue());
                                    Calendar cal = Calendar.getInstance();
                                    cal.setTime(date);
                                    String day_str = "Today";
                                    int day = cal.get(cal.DAY_OF_WEEK);

                                    MyReservations.add(" " + doc.asDocument().getString("SchedulerName").getValue()
                                            + " - " + doc.asDocument().getString("ScheduleName").getValue()
                                            + "\n Day: " +  dayofweek(day)
                                            +"\n Time: " + doc.asDocument().getString("Time").getValue()
                                            +"\n Date: " + doc.asDocument().getString("Date").getValue());

                                    adapter.notifyDataSetChanged();

                                    ResObject tempR = new ResObject();
                                    tempR.OBJ_ID = doc.asDocument().getObjectId("_id").getValue();
                                    tempR.UserID = doc.asDocument().getString("UserID").getValue().toString();
                                    tempR.ScheduleID = doc.asDocument().getString("ScheduleID").getValue().toString();
                                    tempR.SchedulerName = doc.asDocument().getString("SchedulerName").getValue().toString();
                                    tempR.ScheduleName = doc.asDocument().getString("ScheduleName").getValue().toString();
                                    tempR.Time = doc.asDocument().getString("Time").getValue().toString();
                                    tempR.Date = doc.asDocument().getString("Date").getValue().toString();
                                    tempR.Comments = doc.asDocument().getString("Comments").getValue().toString();
                                    SessionData.CurrReservationsList.add(tempR);

                                    //adapter.notifyDataSetChanged();

                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                        else {
                            Log.e("stitch", "Error calling function:", task.getException());
                        }
                    }
                });
    }

    static String dayofweek(int temp)
    {
        if(temp==2)
            return "Monday";
        if(temp==3)
            return "Tuesday";
        if(temp==4)
            return "Wednesday";
        if(temp==5)
            return "Thursday";
        if(temp==6)
            return "Friday";
        if(temp==7)
            return "Saturday";
        if(temp==1)
            return "Sunday";
        return "Unknown Day";
    }

    private void CancelRes(ResObject myobj,int position){

        AlertDialog.Builder mBuilder = new AlertDialog.Builder(HomePage.this,AlertDialog.THEME_HOLO_LIGHT);
        View mView = getLayoutInflater().inflate(R.layout.resinfo,null);
        final TextView CommentsForm = (TextView) mView.findViewById(R.id.Comments);
        final TextView DateForm = (TextView) mView.findViewById(R.id.Res_Date_2);
        final TextView DayTimeForm = (TextView) mView.findViewById(R.id.Res_Day_Time_2);
        final TextView Scheduler_ScheduleForm = (TextView) mView.findViewById(R.id.Scheduler_Schedule_info);
        final Button CancelResB = (Button) mView.findViewById(R.id.CancelRes);



        SimpleDateFormat format = new SimpleDateFormat("M-dd-yyyy");
        int day = -1;
        try{
            Date date = format.parse(myobj.Date);
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            day = cal.get(cal.DAY_OF_WEEK);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        CommentsForm.setText("Comments: "+myobj.Comments);
        DateForm.setText("Date: "+myobj.Date);
        DayTimeForm.setText("Day/Time: "+dayofweek(day)+" - "+myobj.Time);
        Scheduler_ScheduleForm.setText(myobj.SchedulerName+" - "+myobj.ScheduleName);

        mBuilder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

            }
        });

        mBuilder.setView(mView);
        final AlertDialog Reservation_dialog = mBuilder.create();


        CancelResB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Document document = new Document("UserID", myobj.UserID)
                        .append("SchedulerName", myobj.SchedulerName)
                        .append("ScheduleName", myobj.ScheduleName)
                        .append("Time", myobj.Time)
                        .append("Date", myobj.Date);

                client.callFunction("RemoveRes", Arrays.asList(document),BsonValue.class)
                        .addOnCompleteListener(new OnCompleteListener<BsonValue>() {
                            @Override
                            public void onComplete(@NonNull final Task<BsonValue> task) {
                                if (task.isSuccessful()) {
                                    System.out.println("test");
                                    MyReservations.remove(position);
                                    SessionData.CurrReservationsList.remove(position);
                                    adapter.notifyDataSetChanged();
                                    Reservation_dialog.dismiss();
                                }
                                else {
                                    Log.e("stitch", "Error calling function:", task.getException());
                                }
                            }
                        });

                //SessionData.CurrReservationsList.remove(position);


                Toast.makeText(HomePage.this,"Reservation Cancelled",Toast.LENGTH_SHORT).show();
            }
        });

        Reservation_dialog.show();


       // mBuilder.setView(mView);
        //final AlertDialog Reservation_dialog = mBuilder.create();
        //Reservation_dialog.show();

        adapter.notifyDataSetChanged();
    }

    public void ViewSchedulers(){
        finish();
        Intent intent =  new Intent(this,ViewSchedulers.class);
        startActivity(intent);
    }

    public void ReturnToLogin()
    {
        Intent intent =  new Intent(this,LoginActivity.class);
        startActivity(intent);
        MyReservations.clear();
    }
    public void GoToTimeList()
    {
        Intent intent =  new Intent(this,CalenderActivity.class);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        //DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        //if (drawer.isDrawerOpen(GravityCompat.START)) {
        //    drawer.closeDrawer(GravityCompat.START);
        //} else {
        //    super.onBackPressed();
        //}
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_page, menu);
        //menu.getItem(1);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        /*if (id == R.id.action_settings) {
            return true;
        } */
        if (id == R.id.action_LogOut) {
            ReturnToLogin();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
