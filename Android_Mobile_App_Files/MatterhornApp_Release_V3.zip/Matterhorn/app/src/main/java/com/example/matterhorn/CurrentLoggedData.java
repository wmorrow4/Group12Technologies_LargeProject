package com.example.matterhorn;

import org.bson.BsonDocument;

import java.util.ArrayList;

public class CurrentLoggedData {

    public LoggedInUser CurrUser;
    public CurrentScheduler CurrScheduler;
    public CurrentSchedule CurrSchedule;
    public CurrentTime_Date  CurrRes;

    //ignore these arrays for not, not used. created for the sake of having it if we need it
    public ArrayList<String> CurrSchedulersList;
    public ArrayList<String> CurrSchedulesList; //NOTE: this include all schedules between all schedulers
    public ArrayList<ResObject> CurrReservationsList;


    public CurrentLoggedData(String email,String pass,String id, String Fname, String Lname) {
        CurrUser = new LoggedInUser();
        CurrUser.mEmail = email;
        CurrUser.mPassword = pass;
        CurrUser.UserID = id;
        CurrUser.FirstName = Fname;
        CurrUser.LastName = Lname;
        CurrScheduler = new CurrentScheduler();
        CurrSchedule = new CurrentSchedule();
        CurrRes = new CurrentTime_Date();

        CurrSchedulersList = new ArrayList<>();
        CurrSchedulesList = new ArrayList<>();
        CurrReservationsList = new ArrayList<>();
    }



    class LoggedInUser{
        String UserID = "BLANK_ID";
        String mEmail;
        String mPassword;
        String FirstName;
        String LastName;
    }
    class CurrentScheduler{
        String SchedulerName;
        public CurrentScheduler() {

        }
    }
    class CurrentSchedule{
        String ScheduleID = "BLANK_ID";
        String ScheduleName;
        String capacity = "UNUSED";
        String Start_Time;
        String End_Time;
        String Length;
        BsonDocument ScheduleObj;
        public CurrentSchedule() {

        }
    }
    class CurrentTime_Date{
        String ResTime;
        String ResDay;
        String ResDate;
        public CurrentTime_Date() {

        }
    }

    public void LogOutData()
    {
        CurrUser.mEmail = null;
        CurrUser.mPassword = null;
        CurrScheduler.SchedulerName = null;
        CurrSchedule.ScheduleName = null;
        CurrRes.ResDate = null;
        CurrRes.ResDay = null;
        CurrRes.ResTime = null;
    }
}


