package com.example.matterhorn;

import org.bson.types.ObjectId;

public class ResObject {
    String ScheduleID;
    String UserID;
    String SchedulerName ;
    String ScheduleName;
    String Time;
    String Date;
    String Comments;
    ObjectId OBJ_ID;

    public ResObject() {
        this.ScheduleID = "BLANK_ID";
        this.UserID = "BLANK";
        this.SchedulerName = "BLANK";
        this.ScheduleName = "BLANK";
        this.Time = "BLANK";
        this.Date = "BLANK";
        this.Comments = "BLANK";
        this.OBJ_ID = null;
    }
}
